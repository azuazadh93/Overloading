package com.cts.Polymor;

public class Delivery {
    void displayDeliveryDetails(String bowler, String batsman)

    {

        //System.out.println();
String bowlerName[] = bowler.split(" ");
String batsmanName[] = batsman.split(" ");



//  System.out.println("Bowler name"+bowlerName.length);
//  System.out.println("batsman name"+batsmanName.length);
////        String str = "geekss@for@geekss";
//String []bowlerName = bowler.split(" ",1);
//        String []batsmanName = batsman.split(" ",1);
//

////for splitting the letters
//String ans[]=bowlerName[1].split("");
//String ans1[]=batsmanName[1].split("");


 System.out.println("Bowler : " +bowlerName[0]);

 System.out.println("Batsman : " +batsmanName[0]);

        System.out.println(bowler.length());
        System.out.println(batsman.length());






//
//        System.out.println ("Bowler :" +bowler);
//        System.out.println ("Batsman :" +batsman);


//        for(int i=0;i<ans.length;i++) {
//            System.out.println(ans[i]+"   ");
//
//
//            System.out.println("");
//
//        }
//   for(int i=0;i<ans1.length;i++) {
//
//            System.out.println("   "+ans1[i]);
//
//            System.out.println("");
//
//        }


    }


        void displayDeliveryDetails(Long runs)
    {
        System.out.println("Number of runs scored in the delivery : "+runs);
        if(runs==4)
        {
            System.out.println("It is a Boundary.");

        }
        if(runs==6)
        {
            System.out.println("It is a Sixer.");

        }

    }

}

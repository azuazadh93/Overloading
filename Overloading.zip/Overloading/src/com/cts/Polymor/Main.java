package com.cts.Polymor;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
public class Main {

  /* public static void main(String[] args) throws IOException {
       BufferedReader br=new BufferedReader (new InputStreamReader(System.in));*/
public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Menu");
        System.out.println("1.Player");
        System.out.println("2. Runs scored");
        Delivery d = new Delivery();
        int n = in.nextInt();

        switch(n) {
            case 1:
                System.out.println("Bowler name:");
                String bowler = in.nextLine();
                //String bowler = br.readLine();
                in.nextLine();

                System.out.println("Batsman name:");
                String batsman = in.nextLine();
                d.displayDeliveryDetails(bowler, batsman);

                break;

            case 2:

                System.out.println("Run:");
                long runs = in.nextLong();
                d.displayDeliveryDetails(runs);
                break;
        }
    }
}
